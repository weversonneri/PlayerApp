package com.example.playerapp;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button button;
    MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button_player);
        player = MediaPlayer.create(MainActivity.this, R.raw.music);
    }

    public void tocar(View view) {
        if (player != null) {
            if (! player.isPlaying()) {
                player.start();
                button.setText("Pausar");
            } else {
                player.pause();
                button.setText("Tocar");
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (player != null) {
            player = null;
        }
    }
}
